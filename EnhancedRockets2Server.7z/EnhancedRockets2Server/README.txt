Model Credits:

Elbagast
Created the models for:
- Direct Hit
- Black Box
- Liberty Launcher
- Rocket Jumper
- Original

N-Cognito aka N-Cog
Created the models for:
- "Enhanced" Stock Rocket (fixed UVs)
- Festive Rocket
- Festive Black Box Rocket
- Beggar's Bazooka Rocket
- All the Botkiller rockets